
MENU FIRSTCHILD
http://drupal.org/project/menu_firstchild

DESCRIPTION
By default, Drupal requires that you enter a path for each menu link you add/edit from the Menu administration page.
There are cases you may want to create a parent item, without any path, that simply links to its first viewable child item.
Menu Firstchild provides this functionality.

INSTALLATION
Please read instructions at: http://drupal.org/project/menu_firstchild

CONTACT
Henri MEDOT <henri.medot[AT]absyx[DOT]fr>
http://www.absyx.fr
